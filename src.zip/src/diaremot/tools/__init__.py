"""Developer tools for DiaRemot (dependency checks, inspectors)."""
