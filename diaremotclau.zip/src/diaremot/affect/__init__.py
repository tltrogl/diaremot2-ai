"""Affect analysis modules (emotion, intent, paralinguistics)."""

__all__ = [
    "emotion_analyzer",
    "intent_defaults",
    "paralinguistics",
    "sed_panns",
]
